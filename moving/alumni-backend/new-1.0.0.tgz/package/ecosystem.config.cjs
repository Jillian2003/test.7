module.exports = {
  apps: [
    {
      name: 'alumni-api',
      cwd: __dirname,
      script: 'index.js',
      env: {
        PORT: 2490,
      },
    },
    {
      name: 'alumni-swagger',
      cwd: __dirname,
      script: 'swagger-server.js',
      env: {
        PORT: 2456,
        API_BASE_URL: 'http://127.0.0.1:2490',
      },
    },
  ],
};
